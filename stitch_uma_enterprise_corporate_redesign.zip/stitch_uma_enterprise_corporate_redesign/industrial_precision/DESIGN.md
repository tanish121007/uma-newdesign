---
name: Industrial Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf1'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dbe9ff'
  surface-container-highest: '#d5e4fa'
  on-surface: '#0e1c2c'
  on-surface-variant: '#44474d'
  inverse-surface: '#233142'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777e'
  outline-variant: '#c4c6ce'
  surface-tint: '#4c5f7c'
  primary: '#01162f'
  on-primary: '#ffffff'
  primary-container: '#172b45'
  on-primary-container: '#7f93b2'
  inverse-primary: '#b4c8e9'
  secondary: '#4a6176'
  on-secondary: '#ffffff'
  secondary-container: '#cde5ff'
  on-secondary-container: '#50677c'
  tertiary: '#280f00'
  on-tertiary: '#ffffff'
  tertiary-container: '#472000'
  on-tertiary-container: '#cc7f46'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#b4c8e9'
  on-primary-fixed: '#061c35'
  on-primary-fixed-variant: '#354863'
  secondary-fixed: '#cde5ff'
  secondary-fixed-dim: '#b1c9e2'
  on-secondary-fixed: '#031d30'
  on-secondary-fixed-variant: '#32495d'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb785'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#f8f9ff'
  on-background: '#0e1c2c'
  surface-variant: '#d5e4fa'
typography:
  display-hero:
    fontFamily: Manrope
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-technical:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-button:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system establishes an authoritative, editorial-grade digital presence for high-volume corrugated packaging manufacturing. It reflects structural integrity, industrial scale, and bespoke supply chain expertise. 

The aesthetic blends **Modern Corporate** with **Architectural Restraint**:
- **Tone:** Authoritative, institutional, reliable, and deeply technical yet refined.
- **Audience:** Global enterprise procurement heads, supply chain leaders, FMCG packaging buyers, and industrial logistics managers.
- **Principles:** Precision over ornament, architectural structure over decorative flourishes, generous whitespace, and strict typographic hierarchy.
- **Visual Stance:** Avoid fleeting consumer app trends (no glassmorphism, playful blob radii, neon accents, or floating pastel cards). Surfaces must convey the tangible solidity of engineered paperboard, high-caliper fluting, and enterprise-grade reliability.

## Colors

The palette draws directly from industrial engineering and raw packaging materials, elevated through corporate luxury.

- **Primary (`#172B45` - Deep Navy):** The structural core. Used for foundational navigation headers, high-impact display titles, primary CTA fills, and commanding footer anchors.
- **Secondary (`#263D51` - Slate Navy):** Used for secondary headers, sub-navigation tiers, icon containers, and structural section backdrops.
- **Tertiary (`#C77B42` - Muted Copper):** Inspired by Kraft pulp and hot-stamp embossing. Reserved for high-value interactive focal points, precision accent lines, specification badges, and verified industrial certifications. Use with extreme discipline.
- **Neutral / Text (`#263445` - Dense Industrial Slate):** The calibrated reading tone. Ensures effortless legibility across complex specification tables and technical datasheets without the harshness of pure black.
- **Surface Canvas (`#FFFFFF` Pure White & `#F6F7F8` Off-White):** Alternated to demarcate architectural zones and container cards.
- **Structural Borders (`#E9EDF1`):** A hairline grey-blue tone used for all cell partitions, layout bounds, and structural grid rules.

## Typography

The typographic hierarchy pairs **Manrope** for authoritative structural framing with **Inter** for neutral, high-density legibility.

- **Headlines (Manrope):** Geometric, solid, and upright. High-weight display tiers utilize tight negative letter spacing to project enterprise gravitas. Headline casing should remain standard sentence or title case; never full caps for multi-word headings.
- **Body & Data (Inter):** Highly legible neutral grotesque with tall x-height. Engineered for reading technical material, edge crush test (ECT) values, burst test indices, and dimension tables.
- **Technical Metadata (`label-technical`):** Rendered in uppercase with generous tracking (`0.08em`) to delineate product codes, flute specifications (A, B, C, E, Micro), and quality assurance standards (ISO/ASTM).

## Layout & Spacing

Layout follows an architectural rhythm built upon a strict **8px reference grid**. Whitespace conveys prestige, manufacturing capacity, and operational clarity.

### Grid Infrastructure
- **Desktop (≥ 1200px):** 12-column fluid grid, max container width 1360px, 32px (`gutter-desktop`) gutters, 64px (`margin-desktop`) outer padding.
- **Tablet (768px – 1199px):** 8-column fluid grid, 24px (`gutter`) gutters, 40px (`margin-tablet`) outer margins.
- **Mobile (< 768px):** 4-column fluid grid, 16px gutters, 20px (`margin`) outer margins.

### Rhythmic Rules
- **Structural Separation:** Major architectural sections must be spaced using `space-2xl` (mobile) to `space-3xl` (desktop) to avoid visual clutter and maintain an editorial cadence.
- **Information Density:** Specification sheets, quote matrixes, and order portals transition to compact density utilizing `space-xs` through `space-md`.
- **Architectural Lines:** Every split or grid transition should be demarcated with subtle 1px `#E9EDF1` hairpins rather than large colored cards.

## Elevation & Depth

Visual hierarchy is communicated via **flat tectonic planes, calibrated 1px borders, and ultra-subtle ambient grounding**. Deep drop shadows and blurred backdrops are prohibited.

### Tectonic Stratification
1. **Base Foundation (Level 0):** Pure `#FFFFFF` or `#F6F7F8` flat plane.
2. **Structural Enclosures (Level 1):** Flat containers encased in `1px solid #E9EDF1`. Background remains solid `#FFFFFF`.
3. **Elevated Overlays & Flyouts (Level 2):** Layered inspection flyouts, dropdowns, and sticky RFP toolbars use a micro-ambient shadow: `0px 4px 16px -2px rgba(23, 43, 69, 0.06), 0px 1px 2px 0px rgba(23, 43, 69, 0.04)`.
4. **Active/Interactive Focus (Level 3):** Product configurators and modal sheets receive a precision boundary shadow: `0px 12px 32px -4px rgba(23, 43, 69, 0.08)`.

### Border Discipline
All card borders, divider rules, and input peripheries must use crisp `#E9EDF1` lines. Interactive hover states transition this border to `#172B45` or `#C77B42` with an instantaneous 150ms ease, avoiding distracting physical lifting.

## Shapes

The shape vocabulary mirrors physical industrial cutting, slotting, and scoring dies. 

- **Level 1 (Soft):** Structural geometry is defined by ultra-restrained radii. 
  - Standard interactive elements (buttons, inputs, dropdown selectors): `4px` (`0.25rem`).
  - Cards, modal containers, and technical table frames: `4px` or `8px` (`0.5rem`).
- **No Pill Radii:** Buttons and tags must maintain rectilinear integrity. Circular pills communicate consumer lifestyle software and are strictly excluded.
- **Die-Cut Detailing:** Technical imagery and hero graphic sections may incorporate chamfered corner accents (45-degree micro cuts) to echo corrugated structural drawings.

## Components

### Buttons
- **Primary:** Solid `#172B45` background, `#FFFFFF` text, `4px` radius, padding `12px 24px`. On hover: `#263D51`. On active: `#0F1D30`.
- **Secondary / Technical:** Outlined `1px solid #172B45`, transparent background, `#172B45` text. On hover: background `#F6F7F8`.
- **Accent (RFQ / Action Urgent):** Solid `#C77B42`, `#FFFFFF` text. Used exclusively for "Request Commercial Quote" or high-intent enterprise actions. On hover: `#B56C35`.
- **Icon Alignment:** Technical icons (arrows, calipers, download PDFs) must be 16px hairline vectors aligned with 8px horizontal offset.

### Chips & Technical Badges
- **Specification Badges (Flute Profiles, GSM, Bursting Strength):** Flat background `#F6F7F8`, `1px solid #E9EDF1` border, `#263445` text, uppercase typography (`label-technical`), padding `4px 8px`, `2px` radius.
- **Accreditation Badges (ISO, FSC, Eco-grade):** Light copper tint background (`rgba(199, 123, 66, 0.08)`), text `#C77B42`, border `1px solid rgba(199, 123, 66, 0.25)`.

### Input Fields & Selectors
- **Default State:** Background `#FFFFFF`, border `1px solid #E9EDF1`, text `#263445`, padding `12px 16px`, `4px` radius. Typography: `body-md`.
- **Focus State:** Border transitions to `1px solid #172B45`. No oversized glowing outline ring; use a crisp `1px` external hairline or `0 0 0 1px #172B45`.
- **Labels:** Displayed above the input in `label-technical` tracking, `#263D51`.

### Cards & Packaging Units
- **Style:** Flat `#FFFFFF` surface with `1px solid #E9EDF1` border, `4px` radius, zero shadow.
- **Padding:** Generous internal breathing space (`24px` to `32px`).
- **Interaction:** On hover, the border changes to `#263D51` with no upward translate or float.

### Technical Data Tables (ECT, Burst Test, Corrugation Grades)
- **Header:** Background `#F6F7F8`, `1px solid #E9EDF1` bottom border, text `#172B45` using `label-technical`.
- **Row:** Alternating or plain `#FFFFFF` with hairline `#E9EDF1` bottom borders. Cell vertical padding: `14px 16px`. Text uses `body-sm`. Numeric values align right using monospaced numeral styling.

### Custom B2B Component: Box Specification Matrix
A dedicated split-view component: left side displays an interactive 3D/vector line-drawn unfolded box die-line (ECMA/FEFCO standards); right side displays a dense key-value technical parameter list (ply configuration, fluting factor, inner dimensions, burst index) with an inline "Add to Procurement Schedule" button.